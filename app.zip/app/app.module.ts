import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { FilmComponent } from './film/film.component';
import { FilmSearchComponent } from './film-search/film-search.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { StartRatingPipe } from './start-rating.pipe';
import { NotFoundComponent } from './not-found/not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AuthenticationServiceService } from './service/authentication-service.service';
import { RegisterFormComponent } from './register-form/register-form.component';


@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    FilmComponent,
    FilmSearchComponent,
    LoginFormComponent,
    StartRatingPipe,
    NotFoundComponent,
    RegisterFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  exports:[
    FilmComponent
  ],
  providers: [AuthenticationServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
