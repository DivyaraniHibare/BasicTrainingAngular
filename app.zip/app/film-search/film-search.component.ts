import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-film-search',
  templateUrl: './film-search.component.html',
  styleUrls: ['./film-search.component.scss']
})
export class FilmSearchComponent implements OnInit {

  constructor() { }
  films=[];
  FormSubmit=false;

  ngOnInit(): void {
  }

  @Output() loggedIn: EventEmitter<any> = new EventEmitter<any>();

  addNewTask(task: any): void {
    this.loggedIn.emit(task);
  }

  searchFilms(){
    this.FormSubmit=true;
  }

}
